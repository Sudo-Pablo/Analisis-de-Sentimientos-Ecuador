"""
Módulo de utilidades
"""
